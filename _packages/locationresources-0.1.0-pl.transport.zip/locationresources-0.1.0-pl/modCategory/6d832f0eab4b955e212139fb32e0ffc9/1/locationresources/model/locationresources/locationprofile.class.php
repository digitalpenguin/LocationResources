<?php
/**
 * @package locationresources
 */
class LocationProfile extends xPDOSimpleObject {}
?>